import Foundation

struct ChatMessage: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var text: String
    var isFromUser: Bool
    var timestamp: Date = Date()
}

struct Conversation: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var jobId: UUID
    var companyName: String
    var jobTitle: String
    var avatarColorHex: String
    var messages: [ChatMessage] = []

    var lastMessage: ChatMessage? {
        messages.last
    }

    var hasUnread: Bool = true
}
