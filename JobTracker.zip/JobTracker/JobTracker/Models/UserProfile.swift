import Foundation

struct UserProfile: Codable, Equatable {
    var name: String = "Jordan Cruz"
    var headline: String = "iOS Developer"
    var email: String = "jordan.cruz@email.com"
    var phone: String = "+63 912 345 6789"
    var location: String = "Davao Region, PH"
    var bio: String = "Mobile developer who loves building clean, useful apps. Looking for my next great team."
    var skills: [String] = ["Swift", "SwiftUI", "UIKit", "Git", "REST APIs"]
    var yearsOfExperience: Int = 2
}
