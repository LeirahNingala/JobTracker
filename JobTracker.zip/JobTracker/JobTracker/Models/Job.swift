import Foundation

enum JobStatus: String, Codable {
    case available
    case applied
    case saved
    case rejected
}

struct Job: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var title: String
    var company: String
    var location: String
    var salaryRange: String
    var employmentType: String   // Full-time, Part-time, Contract
    var postedDaysAgo: Int
    var description: String
    var requiredSkills: [String]
    var status: JobStatus = .available
    var companyInitialColorHex: String = "4A90D9"

    /// Percentage match between this job's required skills and the given user skills.
    func matchPercentage(userSkills: [String]) -> Int {
        guard !requiredSkills.isEmpty else { return 0 }
        let normalizedUserSkills = Set(userSkills.map { $0.lowercased().trimmingCharacters(in: .whitespaces) })
        let normalizedRequired = requiredSkills.map { $0.lowercased().trimmingCharacters(in: .whitespaces) }
        let matched = normalizedRequired.filter { normalizedUserSkills.contains($0) }
        return Int((Double(matched.count) / Double(normalizedRequired.count)) * 100.0)
    }

    func matchedSkills(userSkills: [String]) -> [String] {
        let normalizedUserSkills = Set(userSkills.map { $0.lowercased().trimmingCharacters(in: .whitespaces) })
        return requiredSkills.filter { normalizedUserSkills.contains($0.lowercased().trimmingCharacters(in: .whitespaces)) }
    }

    func missingSkills(userSkills: [String]) -> [String] {
        let normalizedUserSkills = Set(userSkills.map { $0.lowercased().trimmingCharacters(in: .whitespaces) })
        return requiredSkills.filter { !normalizedUserSkills.contains($0.lowercased().trimmingCharacters(in: .whitespaces)) }
    }
}
