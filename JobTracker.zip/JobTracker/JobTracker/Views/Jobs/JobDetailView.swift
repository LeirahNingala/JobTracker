import SwiftUI

struct JobDetailView: View {
    @EnvironmentObject var viewModel: AppViewModel
    @Environment(\.dismiss) private var dismiss
    let job: Job
    @State private var didApply = false

    private var matched: [String] { job.matchedSkills(userSkills: viewModel.userProfile.skills) }
    private var missing: [String] { job.missingSkills(userSkills: viewModel.userProfile.skills) }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    HStack(spacing: 14) {
                        CompanyAvatar(name: job.company, colorHex: job.companyInitialColorHex, size: 56)
                        VStack(alignment: .leading, spacing: 4) {
                            Text(job.title).font(.title2).fontWeight(.bold)
                            Text(job.company).foregroundColor(.secondary)
                        }
                        Spacer()
                    }

                    HStack(spacing: 10) {
                        MatchBadge(percentage: viewModel.matchPercentage(for: job))
                        Text(job.salaryRange)
                            .font(.subheadline)
                            .fontWeight(.medium)
                    }

                    Divider()

                    VStack(alignment: .leading, spacing: 8) {
                        Label(job.location, systemImage: "mappin.and.ellipse")
                        Label(job.employmentType, systemImage: "clock")
                        Label(job.postedDaysAgo == 0 ? "Posted today" : "Posted \(job.postedDaysAgo)d ago", systemImage: "calendar")
                    }
                    .font(.subheadline)
                    .foregroundColor(.secondary)

                    Divider()

                    VStack(alignment: .leading, spacing: 8) {
                        Text("About this role").font(.headline)
                        Text(job.description).font(.body)
                    }

                    VStack(alignment: .leading, spacing: 10) {
                        Text("Skill match").font(.headline)
                        if !matched.isEmpty {
                            Text("You have").font(.caption).foregroundColor(.secondary)
                            WrapChips(items: matched, highlighted: true)
                        }
                        if !missing.isEmpty {
                            Text("Still needed").font(.caption).foregroundColor(.secondary)
                            WrapChips(items: missing, highlighted: false)
                        }
                    }

                    Spacer(minLength: 30)
                }
                .padding()
            }
            .navigationTitle("Job Details")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Close") { dismiss() }
                }
            }
            .safeAreaInset(edge: .bottom) {
                VStack(spacing: 10) {
                    if didApply || job.status == .applied {
                        Label("Applied", systemImage: "checkmark.seal.fill")
                            .font(.headline)
                            .foregroundColor(.green)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.green.opacity(0.12))
                            .clipShape(RoundedRectangle(cornerRadius: 14))
                    } else {
                        HStack(spacing: 12) {
                            Button {
                                viewModel.saveForLater(job)
                                dismiss()
                            } label: {
                                Image(systemName: "bookmark")
                                    .font(.headline)
                                    .frame(width: 50, height: 50)
                                    .background(Color(.systemGray5))
                                    .clipShape(Circle())
                            }

                            Button {
                                withAnimation {
                                    viewModel.easyApply(to: job)
                                    didApply = true
                                }
                            } label: {
                                Label("Easy Apply", systemImage: "bolt.fill")
                                    .font(.headline)
                                    .frame(maxWidth: .infinity)
                                    .padding()
                                    .background(Color.accentColor)
                                    .foregroundColor(.white)
                                    .clipShape(RoundedRectangle(cornerRadius: 14))
                            }
                        }
                    }
                }
                .padding()
                .background(.ultraThinMaterial)
            }
        }
    }
}

/// Simple flow-layout of chips that wraps to multiple lines.
struct WrapChips: View {
    let items: [String]
    let highlighted: Bool

    var body: some View {
        FlexibleView(data: items, spacing: 8, alignment: .leading) { item in
            SkillChip(text: item, highlighted: highlighted)
        }
    }
}

/// Generic wrapping layout helper (works on iOS 16+).
struct FlexibleView<Data: Collection, Content: View>: View where Data.Element: Hashable {
    let data: Data
    let spacing: CGFloat
    let alignment: HorizontalAlignment
    let content: (Data.Element) -> Content

    @State private var totalHeight = CGFloat.zero

    var body: some View {
        VStack {
            GeometryReader { geometry in
                self.generateContent(in: geometry)
            }
        }
        .frame(height: totalHeight)
    }

    private func generateContent(in g: GeometryProxy) -> some View {
        var width = CGFloat.zero
        var height = CGFloat.zero

        return ZStack(alignment: Alignment(horizontal: alignment, vertical: .top)) {
            ForEach(Array(data), id: \.self) { item in
                content(item)
                    .padding(.trailing, spacing)
                    .padding(.bottom, spacing)
                    .alignmentGuide(.leading, computeValue: { d in
                        if abs(width - d.width) > g.size.width {
                            width = 0
                            height -= d.height
                        }
                        let result = width
                        if item == Array(data).last {
                            width = 0
                        } else {
                            width -= d.width
                        }
                        return result
                    })
                    .alignmentGuide(.top, computeValue: { _ in
                        let result = height
                        if item == Array(data).last {
                            height = 0
                        }
                        return result
                    })
            }
        }
        .background(viewHeightReader($totalHeight))
    }

    private func viewHeightReader(_ binding: Binding<CGFloat>) -> some View {
        GeometryReader { geo -> Color in
            let rect = geo.frame(in: .local)
            DispatchQueue.main.async {
                binding.wrappedValue = rect.size.height
            }
            return .clear
        }
    }
}

#Preview {
    JobDetailView(job: AppViewModel().jobs[0])
        .environmentObject(AppViewModel())
}
