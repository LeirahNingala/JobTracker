import SwiftUI

struct JobCardView: View {
    let job: Job
    let matchPercentage: Int

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            CompanyAvatar(name: job.company, colorHex: job.companyInitialColorHex)

            VStack(alignment: .leading, spacing: 6) {
                Text(job.title)
                    .font(.headline)
                Text(job.company)
                    .font(.subheadline)
                    .foregroundColor(.secondary)

                HStack(spacing: 6) {
                    Label(job.location, systemImage: "mappin.and.ellipse")
                    Text("•")
                    Text(job.employmentType)
                }
                .font(.caption)
                .foregroundColor(.secondary)

                HStack {
                    MatchBadge(percentage: matchPercentage)
                    Spacer()
                    Text(job.postedDaysAgo == 0 ? "Today" : "\(job.postedDaysAgo)d ago")
                        .font(.caption2)
                        .foregroundColor(.secondary)
                }
                .padding(.top, 2)
            }
        }
        .padding(.vertical, 6)
    }
}
