import SwiftUI

struct JobsView: View {
    @EnvironmentObject var viewModel: AppViewModel
    @State private var selectedJob: Job?

    var body: some View {
        NavigationStack {
            List {
                if viewModel.availableJobs.isEmpty {
                    ContentUnavailableViewCompat(
                        title: "No jobs found",
                        message: "Try a different search or check back later.",
                        systemImage: "briefcase"
                    )
                }
                ForEach(viewModel.availableJobs) { job in
                    Button {
                        selectedJob = job
                    } label: {
                        JobCardView(job: job, matchPercentage: viewModel.matchPercentage(for: job))
                    }
                    .buttonStyle(.plain)
                    .swipeActions(edge: .trailing, allowsFullSwipe: true) {
                        Button(role: .destructive) {
                            withAnimation { viewModel.archive(job) }
                        } label: {
                            Label("Archive", systemImage: "archivebox")
                        }
                    }
                    .swipeActions(edge: .leading, allowsFullSwipe: true) {
                        Button {
                            withAnimation { viewModel.easyApply(to: job) }
                        } label: {
                            Label("Easy Apply", systemImage: "bolt.fill")
                        }
                        .tint(.green)
                    }
                }
            }
            .listStyle(.plain)
            .navigationTitle("Jobs For You")
            .searchable(text: $viewModel.searchText, prompt: "Search title or company")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Menu {
                        Button {
                            viewModel.sortByBestMatch = true
                        } label: {
                            Label("Best Match", systemImage: viewModel.sortByBestMatch ? "checkmark" : "")
                        }
                        Button {
                            viewModel.sortByBestMatch = false
                        } label: {
                            Label("Most Recent", systemImage: !viewModel.sortByBestMatch ? "checkmark" : "")
                        }
                    } label: {
                        Image(systemName: "arrow.up.arrow.down.circle")
                    }
                }
            }
            .sheet(item: $selectedJob) { job in
                JobDetailView(job: job)
                    .environmentObject(viewModel)
            }
        }
    }
}

/// Minimal cross-version replacement for ContentUnavailableView (iOS 17+ only API).
struct ContentUnavailableViewCompat: View {
    let title: String
    let message: String
    let systemImage: String

    var body: some View {
        VStack(spacing: 12) {
            Image(systemName: systemImage)
                .font(.system(size: 40))
                .foregroundColor(.secondary)
            Text(title)
                .font(.headline)
            Text(message)
                .font(.subheadline)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 60)
        .listRowSeparator(.hidden)
    }
}

#Preview {
    JobsView().environmentObject(AppViewModel())
}
