import SwiftUI

struct ProfileView: View {
    @EnvironmentObject var viewModel: AppViewModel
    @State private var isEditing = false
    @State private var draftProfile = UserProfile()
    @State private var newSkill = ""

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    VStack(spacing: 10) {
                        Circle()
                            .fill(Color.accentColor.opacity(0.2))
                            .frame(width: 90, height: 90)
                            .overlay(
                                Text(initials(for: viewModel.userProfile.name))
                                    .font(.system(size: 32, weight: .bold))
                                    .foregroundColor(.accentColor)
                            )
                        Text(viewModel.userProfile.name)
                            .font(.title2).fontWeight(.bold)
                        Text(viewModel.userProfile.headline)
                            .foregroundColor(.secondary)
                        Text(viewModel.userProfile.location)
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    .padding(.top, 10)

                    VStack(alignment: .leading, spacing: 10) {
                        HStack {
                            Text("About").font(.headline)
                            Spacer()
                        }
                        Text(viewModel.userProfile.bio)
                            .font(.subheadline)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding()
                    .background(Color(.systemGray6))
                    .clipShape(RoundedRectangle(cornerRadius: 14))

                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Text("Skills").font(.headline)
                            Spacer()
                            Text("Drives your job match %")
                                .font(.caption2)
                                .foregroundColor(.secondary)
                        }
                        WrapChips(items: viewModel.userProfile.skills, highlighted: true)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding()
                    .background(Color(.systemGray6))
                    .clipShape(RoundedRectangle(cornerRadius: 14))

                    VStack(spacing: 10) {
                        StatRow(label: "Years of experience", value: "\(viewModel.userProfile.yearsOfExperience)")
                        StatRow(label: "Email", value: viewModel.userProfile.email)
                        StatRow(label: "Phone", value: viewModel.userProfile.phone)
                    }
                    .padding()
                    .background(Color(.systemGray6))
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                }
                .padding()
            }
            .navigationTitle("Profile")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Edit") {
                        draftProfile = viewModel.userProfile
                        isEditing = true
                    }
                }
            }
            .sheet(isPresented: $isEditing) {
                EditProfileSheet(draftProfile: $draftProfile, newSkill: $newSkill) {
                    viewModel.userProfile = draftProfile
                    isEditing = false
                }
            }
        }
    }

    private func initials(for name: String) -> String {
        let parts = name.split(separator: " ")
        let letters = parts.prefix(2).compactMap { $0.first }
        return String(letters).uppercased()
    }
}

private struct StatRow: View {
    let label: String
    let value: String
    var body: some View {
        HStack {
            Text(label).foregroundColor(.secondary)
            Spacer()
            Text(value).fontWeight(.medium)
        }
        .font(.subheadline)
    }
}

private struct EditProfileSheet: View {
    @Binding var draftProfile: UserProfile
    @Binding var newSkill: String
    let onSave: () -> Void
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            Form {
                Section("Basic Info") {
                    TextField("Name", text: $draftProfile.name)
                    TextField("Headline", text: $draftProfile.headline)
                    TextField("Location", text: $draftProfile.location)
                    Stepper("Years of experience: \(draftProfile.yearsOfExperience)", value: $draftProfile.yearsOfExperience, in: 0...40)
                }

                Section("Contact") {
                    TextField("Email", text: $draftProfile.email)
                        .keyboardType(.emailAddress)
                        .autocapitalization(.none)
                    TextField("Phone", text: $draftProfile.phone)
                        .keyboardType(.phonePad)
                }

                Section("Bio") {
                    TextEditor(text: $draftProfile.bio)
                        .frame(minHeight: 90)
                }

                Section("Skills") {
                    HStack {
                        TextField("Add a skill (e.g. SwiftUI)", text: $newSkill)
                        Button("Add") {
                            addSkill()
                        }
                        .disabled(newSkill.trimmingCharacters(in: .whitespaces).isEmpty)
                    }
                    WrapChips2(
                        items: draftProfile.skills,
                        onRemove: { skill in
                            draftProfile.skills.removeAll { $0 == skill }
                        }
                    )
                }
            }
            .navigationTitle("Edit Profile")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Save") { onSave() }
                        .fontWeight(.semibold)
                }
            }
        }
    }

    private func addSkill() {
        let trimmed = newSkill.trimmingCharacters(in: .whitespaces)
        guard !trimmed.isEmpty, !draftProfile.skills.contains(where: { $0.lowercased() == trimmed.lowercased() }) else {
            newSkill = ""
            return
        }
        draftProfile.skills.append(trimmed)
        newSkill = ""
    }
}

/// Wrapping chip list that supports removal, used in the edit sheet.
private struct WrapChips2: View {
    let items: [String]
    let onRemove: (String) -> Void

    var body: some View {
        FlexibleView(data: items, spacing: 8, alignment: .leading) { item in
            SkillChip(text: item, highlighted: true, onRemove: { onRemove(item) })
        }
    }
}

#Preview {
    ProfileView().environmentObject(AppViewModel())
}
