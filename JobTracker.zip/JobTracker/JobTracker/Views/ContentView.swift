import SwiftUI

struct ContentView: View {
    @EnvironmentObject var viewModel: AppViewModel

    var body: some View {
        TabView {
            JobsView()
                .tabItem {
                    Label("Jobs", systemImage: "briefcase.fill")
                }

            ArchiveView()
                .tabItem {
                    Label("Archive", systemImage: "archivebox.fill")
                }

            MessagesView()
                .tabItem {
                    Label("Messages", systemImage: "message.fill")
                }
                .badge(viewModel.unreadConversationCount > 0 ? "\(viewModel.unreadConversationCount)" : nil)

            ProfileView()
                .tabItem {
                    Label("Profile", systemImage: "person.crop.circle.fill")
                }
        }
    }
}

#Preview {
    ContentView().environmentObject(AppViewModel())
}
