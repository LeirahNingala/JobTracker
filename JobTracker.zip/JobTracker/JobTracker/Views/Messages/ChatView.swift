import SwiftUI

struct ChatView: View {
    @EnvironmentObject var viewModel: AppViewModel
    let conversationId: UUID
    @State private var draft: String = ""

    private var conversation: Conversation? {
        viewModel.conversations.first { $0.id == conversationId }
    }

    var body: some View {
        VStack(spacing: 0) {
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(spacing: 10) {
                        if let messages = conversation?.messages {
                            ForEach(messages) { message in
                                ChatBubble(message: message)
                                    .id(message.id)
                            }
                        }
                    }
                    .padding()
                }
                .onChange(of: conversation?.messages.count) { _ in
                    if let lastId = conversation?.messages.last?.id {
                        withAnimation {
                            proxy.scrollTo(lastId, anchor: .bottom)
                        }
                    }
                }
            }

            Divider()

            HStack(spacing: 10) {
                TextField("Type a message…", text: $draft, axis: .vertical)
                    .textFieldStyle(.roundedBorder)
                    .lineLimit(1...4)

                Button {
                    sendDraft()
                } label: {
                    Image(systemName: "arrow.up.circle.fill")
                        .font(.system(size: 30))
                }
                .disabled(draft.trimmingCharacters(in: .whitespaces).isEmpty)
            }
            .padding()
        }
        .navigationTitle(conversation?.companyName ?? "Chat")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            if let conversation {
                viewModel.markRead(conversation)
            }
        }
    }

    private func sendDraft() {
        guard let conversation else { return }
        let text = draft.trimmingCharacters(in: .whitespaces)
        guard !text.isEmpty else { return }
        viewModel.sendMessage(text, in: conversation)
        draft = ""
    }
}

struct ChatBubble: View {
    let message: ChatMessage

    var body: some View {
        HStack {
            if message.isFromUser { Spacer(minLength: 40) }
            VStack(alignment: message.isFromUser ? .trailing : .leading, spacing: 4) {
                Text(message.text)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 10)
                    .background(message.isFromUser ? Color.accentColor : Color(.systemGray5))
                    .foregroundColor(message.isFromUser ? .white : .primary)
                    .clipShape(RoundedRectangle(cornerRadius: 16))
                Text(message.timestamp, style: .time)
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }
            if !message.isFromUser { Spacer(minLength: 40) }
        }
    }
}

#Preview {
    NavigationStack {
        ChatView(conversationId: UUID())
            .environmentObject(AppViewModel())
    }
}
