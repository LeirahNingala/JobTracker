import SwiftUI

struct MessagesView: View {
    @EnvironmentObject var viewModel: AppViewModel

    var body: some View {
        NavigationStack {
            List {
                if viewModel.conversations.isEmpty {
                    ContentUnavailableViewCompat(
                        title: "No messages yet",
                        message: "Apply to a job to start a conversation with the employer.",
                        systemImage: "message"
                    )
                }
                ForEach(viewModel.conversations) { conversation in
                    NavigationLink {
                        ChatView(conversationId: conversation.id)
                            .environmentObject(viewModel)
                    } label: {
                        ConversationRow(conversation: conversation)
                    }
                }
            }
            .listStyle(.plain)
            .navigationTitle("Messages")
        }
    }
}

struct ConversationRow: View {
    let conversation: Conversation

    var body: some View {
        HStack(spacing: 12) {
            CompanyAvatar(name: conversation.companyName, colorHex: conversation.avatarColorHex)
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Text(conversation.companyName)
                        .font(.headline)
                    Spacer()
                    if let last = conversation.lastMessage {
                        Text(last.timestamp, style: .time)
                            .font(.caption2)
                            .foregroundColor(.secondary)
                    }
                }
                Text(conversation.jobTitle)
                    .font(.caption)
                    .foregroundColor(.secondary)
                if let last = conversation.lastMessage {
                    Text(last.text)
                        .font(.subheadline)
                        .foregroundColor(conversation.hasUnread ? .primary : .secondary)
                        .fontWeight(conversation.hasUnread ? .medium : .regular)
                        .lineLimit(2)
                }
            }
            if conversation.hasUnread {
                Circle()
                    .fill(Color.accentColor)
                    .frame(width: 9, height: 9)
            }
        }
        .padding(.vertical, 4)
    }
}

#Preview {
    MessagesView().environmentObject(AppViewModel())
}
