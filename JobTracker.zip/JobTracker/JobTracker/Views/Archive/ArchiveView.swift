import SwiftUI

struct ArchiveView: View {
    @EnvironmentObject var viewModel: AppViewModel
    @State private var selectedFilter: ArchiveFilter = .applied
    @State private var selectedJob: Job?

    enum ArchiveFilter: String, CaseIterable {
        case applied = "Applied"
        case saved = "Saved"
        case archived = "Archived"
    }

    private var displayedJobs: [Job] {
        switch selectedFilter {
        case .applied: return viewModel.appliedJobs
        case .saved: return viewModel.savedJobs
        case .archived: return viewModel.rejectedJobs
        }
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                Picker("Filter", selection: $selectedFilter) {
                    ForEach(ArchiveFilter.allCases, id: \.self) { filter in
                        Text(filter.rawValue).tag(filter)
                    }
                }
                .pickerStyle(.segmented)
                .padding()

                if displayedJobs.isEmpty {
                    ContentUnavailableViewCompat(
                        title: "Nothing here yet",
                        message: emptyMessage,
                        systemImage: "archivebox"
                    )
                    Spacer()
                } else {
                    List {
                        ForEach(displayedJobs) { job in
                            Button {
                                selectedJob = job
                            } label: {
                                JobCardView(job: job, matchPercentage: viewModel.matchPercentage(for: job))
                            }
                            .buttonStyle(.plain)
                            .swipeActions(edge: .trailing) {
                                if selectedFilter != .archived {
                                    Button(role: .destructive) {
                                        withAnimation { viewModel.archive(job) }
                                    } label: {
                                        Label("Archive", systemImage: "archivebox")
                                    }
                                } else {
                                    Button {
                                        withAnimation { viewModel.restoreToAvailable(job) }
                                    } label: {
                                        Label("Restore", systemImage: "arrow.uturn.left")
                                    }
                                    .tint(.blue)
                                }
                            }
                        }
                    }
                    .listStyle(.plain)
                }
            }
            .navigationTitle("Archive")
            .sheet(item: $selectedJob) { job in
                JobDetailView(job: job)
                    .environmentObject(viewModel)
            }
        }
    }

    private var emptyMessage: String {
        switch selectedFilter {
        case .applied: return "Jobs you easy-apply to will show up here."
        case .saved: return "Bookmark jobs to review them later."
        case .archived: return "Jobs you dismiss will be archived here."
        }
    }
}

#Preview {
    ArchiveView().environmentObject(AppViewModel())
}
