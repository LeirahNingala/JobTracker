import Foundation
import SwiftUI
internal import Combine

@MainActor
final class AppViewModel: ObservableObject {
    @Published var jobs: [Job] = []
    @Published var conversations: [Conversation] = []
    @Published var userProfile: UserProfile = UserProfile()
    @Published var searchText: String = ""
    @Published var sortByBestMatch: Bool = true

    init() {
        loadSampleJobs()
    }

    // MARK: - Derived lists

    var availableJobs: [Job] {
        let filtered = jobs.filter { $0.status == .available }
        let searched = searchText.isEmpty
            ? filtered
            : filtered.filter {
                $0.title.localizedCaseInsensitiveContains(searchText) ||
                $0.company.localizedCaseInsensitiveContains(searchText)
            }
        if sortByBestMatch {
            return searched.sorted {
                $0.matchPercentage(userSkills: userProfile.skills) > $1.matchPercentage(userSkills: userProfile.skills)
            }
        }
        return searched.sorted { $0.postedDaysAgo < $1.postedDaysAgo }
    }

    var appliedJobs: [Job] {
        jobs.filter { $0.status == .applied }
    }

    var savedJobs: [Job] {
        jobs.filter { $0.status == .saved }
    }

    var rejectedJobs: [Job] {
        jobs.filter { $0.status == .rejected }
    }

    var unreadConversationCount: Int {
        conversations.filter { $0.hasUnread }.count
    }

    // MARK: - Actions

    func matchPercentage(for job: Job) -> Int {
        job.matchPercentage(userSkills: userProfile.skills)
    }

    /// "Easy Hiring" one-tap apply. Moves job to Applied and starts a recruiter conversation.
    func easyApply(to job: Job) {
        guard let index = jobs.firstIndex(where: { $0.id == job.id }) else { return }
        jobs[index].status = .applied
        startConversation(for: jobs[index])
    }

    func saveForLater(_ job: Job) {
        guard let index = jobs.firstIndex(where: { $0.id == job.id }) else { return }
        jobs[index].status = .saved
    }

    func archive(_ job: Job) {
        guard let index = jobs.firstIndex(where: { $0.id == job.id }) else { return }
        jobs[index].status = .rejected
    }

    func restoreToAvailable(_ job: Job) {
        guard let index = jobs.firstIndex(where: { $0.id == job.id }) else { return }
        jobs[index].status = .available
    }

    private func startConversation(for job: Job) {
        guard !conversations.contains(where: { $0.jobId == job.id }) else { return }
        let intro = ChatMessage(
            text: "Hi \(userProfile.name.split(separator: " ").first.map(String.init) ?? "there")! Thanks for applying to \(job.title) at \(job.company). We reviewed your profile and would love to schedule a quick chat. Are you free this week?",
            isFromUser: false
        )
        let convo = Conversation(
            jobId: job.id,
            companyName: job.company,
            jobTitle: job.title,
            avatarColorHex: job.companyInitialColorHex,
            messages: [intro],
            hasUnread: true
        )
        conversations.insert(convo, at: 0)
    }

    func sendMessage(_ text: String, in conversation: Conversation) {
        guard let index = conversations.firstIndex(where: { $0.id == conversation.id }) else { return }
        let userMessage = ChatMessage(text: text, isFromUser: true)
        conversations[index].messages.append(userMessage)

        // Simulated auto-reply for demo purposes.
        let reply = ChatMessage(
            text: "Great, noted! Our recruiter will follow up with details shortly.",
            isFromUser: false
        )
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) { [weak self] in
            guard let self, let i = self.conversations.firstIndex(where: { $0.id == conversation.id }) else { return }
            self.conversations[i].messages.append(reply)
        }
    }

    func markRead(_ conversation: Conversation) {
        guard let index = conversations.firstIndex(where: { $0.id == conversation.id }) else { return }
        conversations[index].hasUnread = false
    }

    func updateSkills(_ skills: [String]) {
        userProfile.skills = skills
    }

    // MARK: - Sample data

    private func loadSampleJobs() {
        jobs = [
            Job(title: "iOS Developer", company: "Brightloop Studio", location: "Davao City, PH", salaryRange: "₱45k–65k/mo", employmentType: "Full-time", postedDaysAgo: 1, description: "Join our small mobile team building consumer apps used by thousands. You'll own features end-to-end in SwiftUI.", requiredSkills: ["Swift", "SwiftUI", "REST APIs", "Git"], companyInitialColorHex: "4A90D9"),
            Job(title: "Junior iOS Engineer", company: "Northwind Apps", location: "Remote", salaryRange: "₱35k–50k/mo", employmentType: "Full-time", postedDaysAgo: 3, description: "Great entry point for mobile engineers who know Swift basics. Mentorship provided.", requiredSkills: ["Swift", "UIKit", "Git"], companyInitialColorHex: "E67E22"),
            Job(title: "Full Stack Mobile Developer", company: "PixelHatch", location: "Cebu City, PH", salaryRange: "₱55k–80k/mo", employmentType: "Full-time", postedDaysAgo: 5, description: "Build both the app and backend services for our marketplace platform.", requiredSkills: ["Swift", "SwiftUI", "Node.js", "REST APIs", "SQL"], companyInitialColorHex: "27AE60"),
            Job(title: "SwiftUI Contractor", company: "Marlow Digital", location: "Remote", salaryRange: "$25–35/hr", employmentType: "Contract", postedDaysAgo: 2, description: "Short-term contract to rebuild a legacy UIKit app in SwiftUI.", requiredSkills: ["SwiftUI", "UIKit", "Swift"], companyInitialColorHex: "8E44AD"),
            Job(title: "Mobile QA & Release Engineer", company: "Sable Technologies", location: "Manila, PH", salaryRange: "₱40k–55k/mo", employmentType: "Full-time", postedDaysAgo: 7, description: "Own our release pipeline, TestFlight builds, and manual + automated QA.", requiredSkills: ["Swift", "XCTest", "Fastlane", "Git"], companyInitialColorHex: "C0392B"),
            Job(title: "Senior iOS Engineer", company: "Harborlight", location: "Remote", salaryRange: "$70k–95k/yr", employmentType: "Full-time", postedDaysAgo: 10, description: "Lead architecture decisions for our flagship fintech app.", requiredSkills: ["Swift", "SwiftUI", "Combine", "REST APIs", "SQL"], companyInitialColorHex: "16A085"),
            Job(title: "Product Designer (Mobile)", company: "Brightloop Studio", location: "Davao City, PH", salaryRange: "₱40k–58k/mo", employmentType: "Full-time", postedDaysAgo: 4, description: "Design clean, human interfaces for our iOS product line.", requiredSkills: ["Figma", "Prototyping", "UIKit"], companyInitialColorHex: "2980B9"),
            Job(title: "Part-Time iOS Developer", company: "Coastline Labs", location: "Remote", salaryRange: "₱300–450/hr", employmentType: "Part-time", postedDaysAgo: 6, description: "Flexible part-time role maintaining an existing SwiftUI codebase.", requiredSkills: ["Swift", "SwiftUI", "Git"], companyInitialColorHex: "D35400"),
        ]
    }
}
